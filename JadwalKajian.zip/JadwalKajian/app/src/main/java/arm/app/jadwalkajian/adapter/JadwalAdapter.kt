package arm.app.jadwalkajian.adapter

import android.content.Context
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import arm.app.jadwalkajian.R
import arm.app.jadwalkajian.model.Jadwal

class JadwalAdapter(context: Context, data: List<Jadwal>?) :
    RecyclerView.Adapter<JadwalAdapter.MyHolder>() {

    var context : Context? = context
    var jadwal : List<Jadwal>? = data

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): JadwalAdapter.MyHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_jadwal, parent, false)
        return MyHolder(view)
    }

    override fun getItemCount(): Int {
        return jadwal?.size!!
    }

    override fun onBindViewHolder(holder: JadwalAdapter.MyHolder, position: Int) {

//        if(kondisi == 0) {
//            holder.btnPilih?.visibility = View.GONE
//            holder.btnLihat?.visibility = View.GONE
//            holder.btnLihat2?.visibility = View.VISIBLE
//        }else {
//            holder.btnPilih?.visibility = View.VISIBLE
//            holder.btnLihat?.visibility = View.VISIBLE
//            holder.btnLihat2?.visibility = View.GONE
//        }
        holder.nPemateri?.text = jadwal?.get(position)?.pemateri
        holder.nTempat?.text = jadwal?.get(position)?.tempat
        holder.nAlamat?.text = jadwal?.get(position)?.alamat
        holder.nHari?.text = jadwal?.get(position)?.hari
//        holder.nPemateri?.text = jadwal?.get(position)?.tanggal


    }

    class MyHolder(itemView: View?) : RecyclerView.ViewHolder(itemView!!) {

        var nPemateri : TextView? = itemView?.findViewById(R.id.pemateri)
        var nTempat : TextView? = itemView?.findViewById(R.id.tempat)
        var nAlamat : TextView? = itemView?.findViewById(R.id.alamat)
        var nHari : TextView? = itemView?.findViewById(R.id.hari)
        var nTanggal : TextView? = itemView?.findViewById(R.id.tanggal)
        var nBulantahun : TextView? = itemView?.findViewById(R.id.bulanTahun)

    }


}