package arm.app.jadwalkajian.ui

import android.os.Bundle
import android.support.v4.app.Fragment
import android.support.v7.widget.LinearLayoutManager
import android.support.v7.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import arm.app.jadwalkajian.R
import arm.app.jadwalkajian.adapter.JadwalAdapter
import arm.app.jadwalkajian.model.Jadwal
import arm.app.jadwalkajian.presenter.PresenterJadwal
import arm.app.jadwalkajian.view.JadwalView


class JadwalFragment : Fragment(), JadwalView {

    private val TAG:String = "AQIL PRAKOSO"
    private var presenter: PresenterJadwal? = null
    private var recyclerView: RecyclerView? = null

    companion object {
        fun newInstance(): JadwalFragment {
            val fragment = JadwalFragment()
            val args = Bundle()
            fragment.arguments = args
            return fragment
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_jadwal, container, false)
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        initView()
    }

    private fun initView(){

        recyclerView = view?.findViewById(R.id.rv_jadwal)
        presenter = PresenterJadwal(this)
        presenter?.Tampil()

    }

    override fun Hasil(status: Boolean, msg: String) {
    }

    override fun DataJadwal(result: List<Jadwal>) {

        val adapter = JadwalAdapter(context!!, result)
        val linear = LinearLayoutManager(context)
        recyclerView?.adapter = adapter
        recyclerView?.layoutManager = linear
        recyclerView?.visibility = View.GONE

    }


}
