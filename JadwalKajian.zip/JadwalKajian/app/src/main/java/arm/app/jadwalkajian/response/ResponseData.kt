package arm.app.jadwalkajian.response

import arm.app.jadwalkajian.model.Jadwal
import com.google.gson.annotations.SerializedName

class ResponseData {

    @SerializedName("datajadwal")
    var data: List<Jadwal>? = null
}