package arm.app.jadwalkajian.init

import arm.app.jadwalkajian.model.Jadwal
import arm.app.jadwalkajian.response.ResponseData
import arm.app.jadwalkajian.response.ResponseInsert
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.*

class InitRetrofit {
    fun getInitRetrofit(): Retrofit {

        return Retrofit.Builder().baseUrl("http://localhost/jadwalkajian/").addConverterFactory(
            GsonConverterFactory.create())
            .build()

    }

    fun getInitInstance(): ApiService {
        return getInitRetrofit().create(ApiService::class.java)
    }

}

interface ApiService {

    @GET("get_jadwal")
    fun request_getdata(): Call<ResponseData>

    @GET("get_jadwal/{harix}")
    fun request_getSingleData(@Path("harix") hari:String): Call<ResponseData>

    @POST("insert_jadwal")
    fun request_insert(@Body jadwal : Jadwal): Call<ResponseInsert>

    @PUT("update_jadwal")
    fun request_update(@Body jadwal: Jadwal): Call<ResponseInsert>

    @DELETE("rm_jadwa/{id}")
    fun request_delete_pokok(@Path("id") id: Long): Call<ResponseInsert>



}