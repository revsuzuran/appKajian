package arm.app.jadwalkajian.presenter

import arm.app.jadwalkajian.init.InitRetrofit
import arm.app.jadwalkajian.response.ResponseData
import arm.app.jadwalkajian.view.JadwalView
import retrofit2.Call
import retrofit2.Response

class PresenterJadwal(var view: JadwalView?){

    fun Tampil(){
        val getInit = InitRetrofit().getInitInstance()
        val request = getInit.request_getdata()
        request.enqueue(object : retrofit2.Callback<ResponseData> {
            override fun onFailure(call: Call<ResponseData>?, t: Throwable?) {
            }

            override fun onResponse(call: Call<ResponseData>?, response: Response<ResponseData>?) {
                if (response != null){
                    val result = response.body()?.data!!

                    view?.DataJadwal(result)
                }
            }

        })

    }


}